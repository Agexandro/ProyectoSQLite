package net.ivanvega.mibasedatosp77a;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DAOContactos dao = new DAOContactos(this);
        lv = findViewById(R.id.lv);

        SimpleCursorAdapter adp =
                new SimpleCursorAdapter(
                        this,
                        android.R.layout.simple_list_item_2,
                        dao.getAllCursor(),
                        new String[]{"usuario","email"},
                        new int[]{android.R.id.text1, android.R.id.text2
                        },
                        SimpleCursorAdapter.IGNORE_ITEM_VIEW_TYPE

                );
        lv.setAdapter(adp);
    }

    //Agregar
    public void Add(View view){
        Intent i = new Intent(view.getContext(),Agregar.class);
        startActivity(i);
        finish();
    }

    //Eliminar
    public void Delete(View view){
        Intent i = new Intent(view.getContext(),Delete.class);
        startActivity(i);
        finish();
    }
    //Buscar
    public  void Search(View view){
        Intent i = new Intent(view.getContext(),Search.class);
        startActivity(i);
        finish();
    }
}
