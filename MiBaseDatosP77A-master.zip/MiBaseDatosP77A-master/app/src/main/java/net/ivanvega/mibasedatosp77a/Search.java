package net.ivanvega.mibasedatosp77a;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import androidx.appcompat.app.AppCompatActivity;

public class Search extends AppCompatActivity {
    EditText editText;
    ListView lv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    }
    public void Exit(View view){
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
    public void Searched(View view){
        editText = findViewById(R.id.et_snombre);
        lv2 = findViewById(R.id.lv2);

        DAOContactos dao = new DAOContactos(this);

        SimpleCursorAdapter adp =
                new SimpleCursorAdapter(
                        this,
                        android.R.layout.simple_list_item_2,
                        dao.getAllByUsuario(editText.getText().toString()),
                        new String[]{"usuario","email"},
                        new int[]{android.R.id.text1, android.R.id.text2
                        },
                        SimpleCursorAdapter.IGNORE_ITEM_VIEW_TYPE

                );
        lv2.setAdapter(adp);
        editText.setText("");
    }
}
