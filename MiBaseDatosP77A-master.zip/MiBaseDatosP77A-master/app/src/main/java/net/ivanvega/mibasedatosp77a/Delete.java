package net.ivanvega.mibasedatosp77a;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Delete extends AppCompatActivity {
    EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
    }
    public void Delete(View view){
        editText = findViewById(R.id.et_usuario);
        DAOContactos dao = new DAOContactos(this);
        dao.Delete(editText.getText().toString());
        Toast.makeText(this,"Eliminado correctamente",Toast.LENGTH_SHORT).show();
        editText.setText("");
    }

    public void Exit(View view){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        finish();
    }
}
