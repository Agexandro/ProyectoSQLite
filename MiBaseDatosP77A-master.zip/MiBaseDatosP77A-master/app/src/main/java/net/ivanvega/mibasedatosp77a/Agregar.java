package net.ivanvega.mibasedatosp77a;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Agregar extends AppCompatActivity {
EditText usr;
EditText email;
EditText tel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);
    }

    public void Exit(View view){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        finish();
    }
    public void AddUser(View view){
        usr = findViewById(R.id.et_nombre);
        email = findViewById(R.id.et_email);
        tel = findViewById(R.id.et_telefono);

        DAOContactos dao = new DAOContactos(this);
        dao.insert(new Contacto(0, usr.getText().toString(),
                email.getText().toString(),tel.getText().toString()));

        for (Contacto c : dao.getAll()){
            Toast.makeText(this,
                    "Usuario: "+usr.getText().toString()+" agredado correctamene",
                    Toast.LENGTH_SHORT).show();
        }
        usr.setText("");
        email.setText("");
        tel.setText("");
    }
}
